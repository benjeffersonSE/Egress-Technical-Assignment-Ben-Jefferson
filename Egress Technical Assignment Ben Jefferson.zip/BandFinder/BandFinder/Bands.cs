﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BandFinder
{
    class Bands
    { 
        public void Add(Band band)
        {
            bands.Add(band);
        }

        List<Band> bands = new List<Band>();
        public List<Band> getBands()
        {
            return bands;
        }

        public List<string> getBandName()
        {
            List<string> names = new List<string>();
            foreach (Band band in bands)
            {
                names.Add(band.getBandName());
            }
            return names;
        }

        public List<string> getBandCity()
        {
            List<string> names = new List<string>();
            foreach (Band band in bands)
            {
                names.Add(band.getBandCity());
            }
            return names;
        }


        public List<string> getDescription() 
        {
            List<string> desc = new List<string>(); 
            foreach (Band band in bands)
            {
                desc.Add(band.getDescription());
            }
            return desc;
        }

        public Band Search(string name)
        {
            foreach (Band band in bands)
            {
                if (name == band.getBandName())
                {
                    return band;
                }
            }
            return null;
        }
    }
}
