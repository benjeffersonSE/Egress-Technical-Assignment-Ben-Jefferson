﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace BandFinder
{
    public partial class Form1 : Form
    {

        Bands bands = new Bands();
        Cities cities = new Cities();
        bool Initialise = false;

        public Form1()
        {
            InitializeComponent();
            listBox1.Items.Clear();
            listBox1.Items.Add("This is a band finder! : Created by Ben Jefferson");
            listBox1.Items.Add("");
            listBox1.Items.Add("Here you will be able to see which bands are");
            listBox1.Items.Add(" from the major 10 cities in the UK!");
            listBox1.Items.Add("");
            listBox1.Items.Add("You will be able to see by clicking on the city.");
            listBox1.Items.Add("You can also search by name or genre.");
            listBox1.Items.Add("");
            listBox1.Items.Add("Clicking on the band will also give you a more");
            listBox1.Items.Add(" indetailed descripton including their genre.");
            listBox1.Items.Add("");
            listBox1.Items.Add("Additionally, you can add a band to the system");
            listBox1.Items.Add(" yourself including a new city,");
            listBox1.Items.Add(" if it does not already exist!");
            listBox1.Items.Add("");
            listBox1.Items.Add("Just start by clicking on the Initialise Button!"); 
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if(!Initialise) 
            {
                City city1 = new City(); cities.Add(city1); city1.setCityName("London");
                City city2 = new City(); cities.Add(city2); city2.setCityName("Manchester");
                City city3 = new City(); cities.Add(city3); city3.setCityName("Brighton");
                City city4 = new City(); cities.Add(city4); city4.setCityName("Glasgow");
                City city5 = new City(); cities.Add(city5); city5.setCityName("Bristol");
                City city6 = new City(); cities.Add(city6); city6.setCityName("Leeds");
                City city7 = new City(); cities.Add(city7); city7.setCityName("Birmingham");
                City city8 = new City(); cities.Add(city8); city8.setCityName("Liverpool");
                City city9 = new City(); cities.Add(city9); city9.setCityName("Sheffield");
                City city10 = new City(); cities.Add(city10); city10.setCityName("Dublin");

                Band band1 = new Band(); bands.Add(band1); band1.setBandCity("London"); band1.setBandName("The Rolling Stones"); band1.setGenre("Rock, Blues"); band1.setDescription("The Rolling Stones are an English rock band formed in London in 1962. As a diverging act to the popular pop rock of the early 1960s, the Rolling Stones pioneered the gritty, heavier-driven sound that came to define hard rock.");
                Band band2 = new Band(); bands.Add(band2); band2.setBandCity("London"); band2.setBandName("Led Zeppelin"); band2.setGenre("Hard Rock"); band2.setDescription("Led Zeppelin were an English rock band formed in London in 1968. The group consisted of vocalist Robert Plant, guitarist Jimmy Page, bassist/keyboardist John Paul Jones, and drummer John Bonham.");
                Band band3 = new Band(); bands.Add(band3); band3.setBandCity("London"); band3.setBandName("The Clash"); band3.setGenre("Punk Rock");  band3.setDescription("The Clash were an English rock band formed in London in 1976 as a key player in the original wave of British punk rock. They also contributed to the post-punk and new wave movements that emerged in the wake of punk and employed elements of a variety of genres including reggae, dub, funk, ska, and rockabilly.");
                Band band4 = new Band(); bands.Add(band4); band4.setBandCity("London"); band4.setBandName("Queen"); band4.setGenre("Rock"); band4.setDescription("Queen are a British rock band formed in London in 1970. Their classic line-up was Freddie Mercury, Brian May, Roger Taylor and John Deacon.");
                Band band5 = new Band(); bands.Add(band5); band5.setBandCity("London"); band5.setBandName("Blur"); band5.setGenre("Britpop, Indie Rock"); band5.setDescription("Blur are an English rock band. Formed in London in 1988, the group consists of singer Damon Albarn, guitarist Graham Coxon, bassist Alex James and drummer Dave Rowntree. Blur's debut album Leisure incorporated the sounds of Madchester and shoegazing.");
                Band band6 = new Band(); bands.Add(band6); band6.setBandCity("London"); band6.setBandName("FleetWood Mac"); band6.setGenre("Pop Rock, Folk Rock"); band6.setDescription("Fleetwood Mac are a British-American rock band, formed in London in 1967. Fleetwood Mac were founded by guitarist Peter Green, drummer Mick Fleetwood and guitarist Jeremy Spencer, before bassist John McVie joined the lineup for their self-titled debut album. Danny Kirwan joined as a third guitarist in 1968.");
                Band band7 = new Band(); bands.Add(band7); band7.setBandCity("London"); band7.setBandName("Pink Floyd"); band7.setGenre("Progressive Rock, Art Rock"); band7.setDescription("Pink Floyd were an English rock band formed in London in 1965. Gaining a following as a psychedelic pop group, they were distinguished for their extended compositions, sonic experimentation, philosophical lyrics and elaborate live shows, and became a leading band of the progressive rock genre.");
                Band band8 = new Band(); bands.Add(band8); band8.setBandCity("London"); band8.setBandName("Mumford & Sons"); band8.setGenre("Folk Rock"); band8.setDescription("Mumford & Sons are a British folk rock band formed in London in 2007. The band consists of Marcus Mumford, Ben Lovett, Winston Marshall and Ted Dwane. Mumford & Sons have released four studio albums: Sigh No More, Babel, Wilder Mind and Delta.");

                Band band9 = new Band(); bands.Add(band9); band9.setBandCity("Manchester"); band9.setBandName("The Stone Roses"); band9.setGenre("Alt Indie Rock"); band9.setDescription("The Stone Roses were an English rock band formed in Manchester in 1983. One of the pioneering groups of the Madchester movement in the late 1980s and early 1990s, the band's classic and most prominent lineup consisted of vocalist Ian Brown, guitarist John Squire, bassist Mani and drummer Reni.");
                Band band10 = new Band(); bands.Add(band10); band10.setBandCity("Manchester"); band10.setBandName("The Smiths"); band10.setGenre("Indie Rock, Post-punk Rock"); band10.setDescription("The Smiths were an English rock band formed in Manchester in 1982. Consisting of vocalist Morrissey, guitarist Johnny Marr, bassist Andy Rourke, and drummer Mike Joyce, critics consider the band one of the most important to emerge from the British independent music scene of the 1980s.");
                Band band11 = new Band(); bands.Add(band11); band11.setBandCity("Manchester"); band11.setBandName("Oasis"); band11.setGenre("Rock, Britpop"); band11.setDescription("Oasis were an English rock band formed in Manchester in 1991. Developed from an earlier group, the Rain, the band originally consisted of Liam Gallagher, Paul Arthurs, Paul McGuigan, and Tony McCarroll.");
                Band band12 = new Band(); bands.Add(band12); band12.setBandCity("Manchester"); band12.setBandName("Take That"); band12.setGenre("Pop"); band12.setDescription("Take That are an English pop group formed in Manchester in 1990. The group currently consists of Gary Barlow, Howard Donald and Mark Owen. The original line-up also featured Jason Orange and Robbie Williams.");
                Band band13 = new Band(); bands.Add(band13); band13.setBandCity("Manchester"); band13.setBandName("808 State"); band13.setGenre("Electronica"); band13.setDescription("808 State are an English electronic music group formed in 1987 in Manchester, taking their name from the Roland TR-808 drum machine. They were formed by Graham Massey, Martin Price and Gerald Simpson, and they released their debut album, Newbuild, in September 1988.");
                Band band14 = new Band(); bands.Add(band14); band14.setBandCity("Manchester"); band14.setBandName("Herman's Hermits"); band14.setGenre("Pop"); band14.setDescription("Herman's Hermits are an English beat rock and pop group formed in 1964 in Manchester, originally called Herman and His Hermits and featuring lead singer Peter Noone.");
                Band band15 = new Band(); bands.Add(band15); band15.setBandCity("Manchester"); band15.setBandName("Simply Red"); band15.setGenre("Pop, Soul"); band15.setDescription("Simply Red is a British soul and pop band which formed in Manchester in 1985. The lead vocalist of the band is singer and songwriter Mick Hucknall, who, by the time the band initially disbanded in 2010, was the only original member left.");
                Band band16 = new Band(); bands.Add(band16); band16.setBandCity("Manchester"); band16.setBandName("The Chemical Brothers"); band16.setGenre("Electronica"); band16.setDescription("The Chemical Brothers are a British electronic music duo composed of Tom Rowlands and Ed Simons, originating in Manchester in 1989. Along with the Prodigy, Fatboy Slim, and other fellow acts, they were pioneers at bringing the big beat genre to the forefront of pop culture.");

                Band band17 = new Band(); bands.Add(band17); band17.setBandCity("Brighton"); band17.setBandName("The Kooks"); band17.setGenre("Indie Rock, Post Punk"); band17.setDescription("The Kooks are an English indie rock band formed in 2004 in Brighton. The band currently consists of Luke Pritchard, Hugh Harris and Alexis Nunez. The original bassist was Max Rafferty, and the founding drummer was Paul Garred. The lineup of the band remained constant until the departure of Rafferty in 2008.");
                Band band18 = new Band(); bands.Add(band18); band18.setBandCity("Brighton"); band18.setBandName("The Magic Gang"); band18.setGenre("Indie Rock"); band18.setDescription("Comprised of Angus Taylor (bass), Jack Kaye (vocals, guitar), Kristian Smith (vocals, guitar), and Paeris Giles (drums), the band cited American band Weezer as a major influence. They put out their debut single, Alright, in 2015, and over the following few years released three EPs and a number of singles.");
                Band band19 = new Band(); bands.Add(band19); band19.setBandCity("Brighton"); band19.setBandName("Blood Red Shoes"); band19.setGenre("Indie Rock, Garage Rock"); band19.setDescription("Blood Red Shoes are an English alternative rock duo from Brighton consisting of Laura-Mary Carter and Steven Ansell. They have released five full-length albums, Box of Secrets, Fire Like This, In Time to Voices, Blood Red Shoes and Get Tragic as well as several EPs and a number of singles.");
                Band band20 = new Band(); bands.Add(band20); band20.setBandCity("Brighton"); band20.setBandName("Royal Blood"); band20.setGenre("Alternative Rock"); band20.setDescription("Royal Blood are an English rock duo formed in Brighton in 2011, consisting of Mike Kerr and Ben Thatcher. Their sound is anchored in Kerr's unique bass playing technique, in which he uses various effects pedals to make his electric bass sound like a standard electric guitar.");
                Band band21 = new Band(); bands.Add(band21); band21.setBandCity("Brighton"); band21.setBandName("The Electric Soft Parade"); band21.setGenre("Indie Rock"); band21.setDescription("The Electric Soft Parade are an English psychedelic pop band from Brighton, comprising brothers Alex and Thomas White, the creative core of the band, as well as a number of other musicians.");
                Band band22 = new Band(); bands.Add(band22); band22.setBandCity("Brighton"); band22.setBandName("Architects"); band22.setGenre("Metalcore"); band22.setDescription("Architects are a British metalcore band from Brighton, East Sussex, formed in 2004 by twin brothers Dan and Tom Searle. The band now consists of Dan Searle on drums, Sam Carter on vocals, Alex Dean on bass, and Adam Christianson and Josh Middleton on guitars. They have been signed to Epitaph Records since 2013.");
                Band band23 = new Band(); bands.Add(band23); band23.setBandCity("Brighton"); band23.setBandName("The Mummers"); band23.setGenre("Electronica, Alternative rock"); band23.setDescription("The Mummers are a band based in the English seaside town of Brighton, centred on London-born singer/songwriter Raissa Khan-Panni, composer Mark Horwood, producer/writer Paul Sandrone and co-producer/manager Alastair Cunningham.");
                Band band24 = new Band(); bands.Add(band24); band24.setBandCity("Brighton"); band24.setBandName("Esben and the Witch"); band24.setGenre("Post-rock"); band24.setDescription("Esben and the Witch are a British three piece rock band formed in Brighton in 2008. consisting of Rachel Davies, Thomas Fisher, and Daniel Copeman. Their name comes from the Danish fairytale, Esben and the Witch");

                Band band25 = new Band(); bands.Add(band25); band25.setBandCity("Liverpool"); band25.setBandName("The Beatles"); band25.setGenre("Rock, Pop"); band25.setDescription("The Beatles were an English rock band formed in Liverpool in 1960. The group, whose best-known line-up comprised John Lennon, Paul McCartney, George Harrison and Ringo Starr, are regarded as the most influential band of all time.");
                Band band26 = new Band(); bands.Add(band26); band26.setBandCity("Liverpool"); band26.setBandName("The Wombats"); band26.setGenre("Indie Rock, Indie Pop"); band26.setDescription("The Wombats are an English indie rock band formed in Liverpool in 2003. Since its inception, the band's line-up has consisted of Matthew Murphy, Tord Øverland Knudsen, and Dan Haggis. The band is signed to 14th Floor Records and Bright Antenna. They have sold over 1 million copies worldwide.");
                Band band27 = new Band(); bands.Add(band27); band27.setBandCity("Liverpool"); band27.setBandName("Circa Waves"); band27.setGenre("Indie Rock"); band27.setDescription("Circa Waves are an English indie rock band formed in Liverpool in 2013. The band consists of vocalist and guitarist Kieran Shudall, guitarist Joe Falconer, bassist Sam Rourke, and drummer Colin Jones.");
                Band band28 = new Band(); bands.Add(band28); band28.setBandCity("Liverpool"); band28.setBandName("Frankie Goes To Hollywood"); band28.setGenre("Dance Rock, New Wave"); band28.setDescription("Frankie Goes to Hollywood were a British band formed in Liverpool, England, in the 1980s. The group was fronted by Holly Johnson, with Paul Rutherford, Peter Gill, Mark O'Toole and Brian Nash.");
                Band band29 = new Band(); bands.Add(band29); band29.setBandCity("Liverpool"); band29.setBandName("The Zutons"); band29.setGenre("Indie Rock, Post-punk"); band29.setDescription("The Zutons were an English indie rock band, formed in 2001 in Liverpool. They released their debut album, Who Killed...... The Zutons? in May 2004 and achieved chart success with, Why Won't You Give Me Your Love? and Valerie , both taken from their second studio album Tired of Hanging Around in 2006.");
                Band band30 = new Band(); bands.Add(band30); band30.setBandCity("Liverpool"); band30.setBandName("The La's"); band30.setGenre("Alternative rock, Indie rock"); band30.setDescription("The La's were an English rock band from Liverpool, originally active from 1983 until 1992. Fronted by singer, songwriter and guitarist Lee Mavers, the group are best known for their hit single, There She Goes.");
                Band band31 = new Band(); bands.Add(band31); band31.setBandCity("Liverpool"); band31.setBandName("The Lightning Seeds"); band31.setGenre("Alternative rock, Indie pop, Britpop"); band31.setDescription("The Lightning Seeds are an English rock band formed in Liverpool in 1989 by Ian Broudie, formerly of the bands Big in Japan and Original Mirrors. Originally a studio-based solo project for Broudie, the Lightning Seeds expanded into a touring band following Jollification.");
                Band band32 = new Band(); bands.Add(band32); band32.setBandCity("Liverpool"); band32.setBandName("Cast"); band32.setGenre("Britpop, Alternative rock, Indie rock"); band32.setDescription("Cast are an English indie rock band formed in Liverpool in 1992 by John Power and Peter Wilkinson after Power left The La's and Wilkinson's former band Shack had split. Following early line-ups with different guitarists and drummers, Liam Skin Tyson and Keith O'Neill joined Cast in 1993.");

                Band band33 = new Band(); bands.Add(band33); band33.setBandCity("Glasgow"); band33.setBandName("Simple Minds"); band33.setGenre("Post-punk, Art rock"); band33.setDescription("Simple Minds are a Scottish rock band formed in Glasgow in 1977. Simple Minds have released a string of hit singles, becoming best known internationally for their 1985 hit Don't You, from the soundtrack of the film The Breakfast Club");
                Band band34 = new Band(); bands.Add(band34); band34.setBandCity("Glasgow"); band34.setBandName("Deacon Blue"); band34.setGenre("Pop music, Rock"); band34.setDescription("Deacon Blue are a Scottish pop rock band formed in Glasgow during 1985. The line-up of the band consists of vocalists Ricky Ross and Lorraine McIntosh, keyboard player James Prime and drummer Dougie Vipond.");
                Band band35 = new Band(); bands.Add(band35); band35.setBandCity("Glasgow"); band35.setBandName("Franz Ferdinand"); band35.setGenre("Indie rock, Post-punk revival"); band35.setDescription("Franz Ferdinand are a Scottish rock band formed in Glasgow in 2002. The band's original lineup was composed of Alex Kapranos, Nick McCarthy, Bob Hardy, and Paul Thomson. Julian Corrie and Dino Bardot joined the band in 2017 after McCarthy left during the previous year.");
                Band band36 = new Band(); bands.Add(band36); band36.setBandCity("Glasgow"); band36.setBandName("Primal Scream"); band36.setGenre("Alternative rock, Electronica"); band36.setDescription("Primal Scream are a Scottish rock band originally formed in 1982 in Glasgow by Bobby Gillespie and Jim Beattie. The band's current lineup consists of Gillespie, Andrew Innes, Martin Duffy, Simone Butler, and Darrin Mooney.");
                Band band37 = new Band(); bands.Add(band37); band37.setBandCity("Glasgow"); band37.setBandName("Mogwai"); band37.setGenre("Post-rock, Instrumental rock"); band37.setDescription("Mogwai are a Scottish post-rock band, formed in 1995 in Glasgow. The band consists of Stuart Braithwaite, Barry Burns, Dominic Aitchison, and Martin Bulloch.");
                Band band38 = new Band(); bands.Add(band38); band38.setBandCity("Glasgow"); band38.setBandName("The Pastels"); band38.setGenre("Indie pop, Alternative rock, Post-punk"); band38.setDescription("The Pastels are an indie rock group from Glasgow formed in 1981. They were a key act of the Scottish and British independent music scenes of the 1980s, and are specifically credited for the development of an independent and confident music scene in Glasgow.");
                Band band39 = new Band(); bands.Add(band39); band39.setBandCity("Glasgow"); band39.setBandName("Belle and Sebastian"); band39.setGenre("Indie pop, Folk rock"); band39.setDescription("Belle and Sebastian are a Scottish indie pop band formed in Glasgow in 1994. Led by Stuart Murdoch, the band has released nine albums. Much of their work had been released on Jeepster Records, but they are now signed to Matador Records worldwide.");
                Band band40 = new Band(); bands.Add(band40); band40.setBandCity("Glasgow"); band40.setBandName("Attic Lights"); band40.setGenre("Indie rock, Power pop"); band40.setDescription("Attic Lights are a Scottish indie rock band from Glasgow, Scotland, formed in 2005 by Kev Sherry, Colin McArdle and Jamie Houston, later joined by Tim Davidson and Noel O'Donnell. The four-part harmonies in a number of their songs have led to critical comparisons with Teenage Fanclub and The Beach Boys.");

                Band band41 = new Band(); bands.Add(band41); band41.setBandCity("Bristol"); band41.setBandName("Portishead"); band41.setGenre("Experimental rock, Electronica, Alternative rock"); band41.setDescription("Portishead are an English band formed in 1991 in Bristol. They are often considered one of the pioneers of trip hop music. The band is named after the nearby town of the same name, eight miles west of Bristol, along the coast.");
                Band band42 = new Band(); bands.Add(band42); band42.setBandCity("Bristol"); band42.setBandName("Massive Attack"); band42.setGenre("Trip hop"); band42.setDescription("Massive Attack are an English electronic band formed in 1988 in Bristol, England, by Robert 3D Del Naja, Adrian Tricky Thaws, Andrew Mushroom Vowles and Grant Daddy G Marshall. The band currently consists of Del Naja, Thaws and Marshall, with Shara Nelson and Horace Andy as guest vocalists.");
                Band band43 = new Band(); bands.Add(band43); band43.setBandCity("Bristol"); band43.setBandName("Idles"); band43.setGenre("Punk rock, Post-punk, Hardcore punk, Indie rock,"); band43.setDescription("Idles are a British rock band formed in Bristol in 2009. The band consists of Joe Talbot, Mark Bowen, Lee Kiernan, Adam Devonshire and Jon Beavis. Their debut album, Brutalism, was released in 2017 to critical acclaim, as was their second album Joy as an Act of Resistance in 2018.");
                Band band44 = new Band(); bands.Add(band44); band44.setBandCity("Bristol"); band44.setBandName("The Pop Group"); band44.setGenre("Post-punk, Avant-funk, Experimental music"); band44.setDescription("The Pop Group are an English band formed in Bristol in 1977 by vocalist Mark Stewart, guitarist John Waddington, bassist Simon Underwood, guitarist/saxophonist Gareth Sager, and drummer Bruce Smith.");
                Band band45 = new Band(); bands.Add(band45); band45.setBandCity("Bristol"); band45.setBandName("Vice Squad"); band45.setGenre("Punk rock, Street punk"); band45.setDescription("Vice Squad are an English punk rock band formed in 1979 in Bristol. The band was formed from two other local punk bands, The Contingent and TV Brakes. The songwriter and vocalist Beki Bondage was a founding member of the band.");
                Band band46 = new Band(); bands.Add(band46); band46.setBandCity("Bristol"); band46.setBandName("The Cortinas"); band46.setGenre("Punk rock"); band46.setDescription("The Cortinas were a Bristol-based punk rock band, originally active between 1976 and 1978. Guitarist Nick Sheppard went on to play with the Clash. In 2001, the band's debut single, Fascist Dictator, was included in a leading British music magazine's list of the best punk-rock singles of all-time.");
                Band band47 = new Band(); bands.Add(band47); band47.setBandCity("Bristol"); band47.setBandName("Strangelove"); band47.setGenre("Alternative rock, Indie rock, Progressive rock, Britpop"); band47.setDescription("Strangelove were an English alternative rock band, formed in Bristol in 1991 comprising singer Patrick Duff, guitarists Alex Lee & Julian Poole, bassist Joe Allen and John Langley on drums. They released three albums before they disbanded in 1998.");
                Band band48 = new Band(); bands.Add(band48); band48.setBandCity("Bristol"); band48.setBandName("Black Roots"); band48.setGenre("Reggae"); band48.setDescription("Black Roots are a roots reggae band from the St. Paul's area of Bristol, England, formed in 1979. They toured extensively in the UK and Europe in the 1980s and early 1990s releasing several albums and singles during that time before disappearing from the music scene for about ten years.");

                Band band49 = new Band(); bands.Add(band49); band49.setBandCity("Leeds"); band49.setBandName("Kaiser Chiefs"); band49.setGenre("Indie rock, Post-punk revival, New wave"); band49.setDescription("Kaiser Chiefs are an English indie rock band from Leeds who formed in 2000 as Parva, releasing one studio album, 22, in 2003, before renaming and establishing themselves in their current name that same year.");
                Band band50 = new Band(); bands.Add(band50); band50.setBandCity("Leeds"); band50.setBandName("Gang of Four"); band50.setGenre("Post-punk, Dance-punk, Funk rock"); band50.setDescription("Gang of Four were an English post-punk band, formed in 1976 in Leeds. The original members were singer Jon King, guitarist Andy Gill, bass guitarist Dave Allen and drummer Hugo Burnham. There have been many different line-ups including, among other notable musicians, Sara Lee, Mark Heaney and Gail Ann Dorsey.");
                Band band51 = new Band(); bands.Add(band51); band51.setBandCity("Leeds"); band51.setBandName("Soft Cell"); band51.setGenre("New Wave, Post-Punk"); band51.setDescription("Soft Cell are an English synthpop duo who came to prominence in the early 1980s. The duo consisted of vocalist Marc Almond and instrumentalist David Ball. The band are primarily known for their 1981 hit version of Tainted Love and their platinum-selling debut album Non-Stop Erotic Cabaret.");
                Band band52 = new Band(); bands.Add(band52); band52.setBandCity("Leeds"); band52.setBandName("iLiKETRAiNS"); band52.setGenre("Alternative rock, Post-rock"); band52.setDescription("I Like Trains is an English alternative/post-rock band, formed in Leeds, West Yorkshire, England. The group play brooding songs featuring sparse piano and guitar, baritone vocals, uplifting choral passages and reverberant orchestral crescendos.");
                Band band53 = new Band(); bands.Add(band53); band53.setBandCity("Leeds"); band53.setBandName("The Sisters of Mercy"); band53.setGenre("Gothic rock, Post-punk, New wave"); band53.setDescription("The Sisters of Mercy are an English rock band, formed in 1980 in Leeds. After achieving early underground fame there, the band had their commercial breakthrough in the mid-1980s and sustained it until the early 1990s, when they stopped releasing new recorded output in protest against their record company WEA.");
                Band band54 = new Band(); bands.Add(band54); band54.setBandCity("Leeds"); band54.setBandName("The Mekons"); band54.setGenre("Punk rock, Post-punk, Alternative rock"); band54.setDescription("The Mekons are a British-American post-punk band that formed in the late 1970s as an art collective. They are one of the longest-running and most prolific of the first-wave British punk rock bands.");
                Band band55 = new Band(); bands.Add(band55); band55.setBandCity("Leeds"); band55.setBandName("The Mission"); band55.setGenre("Gothic rock, Post-punk, Hard rock, Alternative rock"); band55.setDescription("The Mission are an English gothic rock band formed in 1986. Initially known as The Sisterhood, the band was started by frontman Wayne Hussey and bassist Craig Adams, soon adding drummer Mick Brown and guitarist Simon Hinkler.");
                Band band56 = new Band(); bands.Add(band56); band56.setBandCity("Leeds"); band56.setBandName("Age of Chance"); band56.setGenre("Alternative rock, Electronic dance music"); band56.setDescription("Age of Chance were a British alternative rock-dance crossover band from Leeds, England, active from 1983 to 1991. They were perhaps most known for their mutant metallic cover of Prince's Kiss which topped the UK Indie Chart in 1986, and peaked at No. 50 in the UK Singles Chart in January the following year.");

                Band band57 = new Band(); bands.Add(band57); band57.setBandCity("Birmingham"); band57.setBandName("Black Sabbath"); band57.setGenre("Heavy metal"); band57.setDescription("Black Sabbath were an English rock band formed in Birmingham in 1968 by guitarist Tony Iommi, drummer Bill Ward, bassist Geezer Butler and vocalist Ozzy Osbourne. They are often cited as pioneers of heavy metal music.");
                Band band58 = new Band(); bands.Add(band58); band58.setBandCity("Birmingham"); band58.setBandName("UB40"); band58.setGenre("Reggae, Pop music, Dub"); band58.setDescription("UB40 are an English reggae and pop band, formed in December 1978 in Birmingham, England. The band has had more than 50 singles in the UK Singles Chart, and has also achieved considerable international success.");
                Band band59 = new Band(); bands.Add(band59); band59.setBandCity("Birmingham"); band59.setBandName("Electric Light Orchestra"); band59.setGenre("Progressive pop, Pop rock, Art rock, Progressive rock"); band59.setDescription("The Electric Light Orchestra are an English rock band formed in Birmingham in 1970 by songwriters-multi-instrumentalists Jeff Lynne and Roy Wood with drummer Bev Bevan. Their music is characterised by a fusion of Beatlesque pop, classical arrangements and futuristic iconography.");
                Band band60 = new Band(); bands.Add(band60); band60.setBandCity("Birmingham"); band60.setBandName("Duran Duran"); band60.setGenre("New wave, Synth-pop, Dance-rock"); band60.setDescription("Duran Duran are an English new wave band formed in Birmingham in 1978. The group were a leading band in the MTV-driven Second British Invasion of the US in the 1980s.");
                Band band61 = new Band(); bands.Add(band61); band61.setBandCity("Birmingham"); band61.setBandName("The Moody Blues"); band61.setGenre("Progressive, Art Rock, Rock"); band61.setDescription("The Moody Blues are a rock band formed in Birmingham, England, in 1964, initially consisting of keyboardist Mike Pinder, multi-instrumentalist Ray Thomas, guitarist Denny Laine, drummer Graeme Edge, and bassist Clint Warwick. The group came to prominence playing rhythm and blues music.");
                Band band62 = new Band(); bands.Add(band62); band62.setBandCity("Birmingham"); band62.setBandName("The Move"); band62.setGenre("Rock, Psychedelic pop, Freakbeat, Psychedelic rock, Progressive rock"); band62.setDescription("The Move were a British rock band of the late 1960s and the early 1970s. They scored nine top 20 UK singles in five years, but were among the most popular British bands not to find any real success in the United States.");
                Band band63 = new Band(); bands.Add(band63); band63.setBandCity("Birmingham"); band63.setBandName("Judas Priest"); band63.setGenre("Heavy metal"); band63.setDescription("Judas Priest are an English heavy metal band formed in Birmingham in 1969. They have sold over 50 million copies of their albums, and are frequently ranked as one of the greatest metal bands of all time.");
                Band band64 = new Band(); bands.Add(band64); band64.setBandCity("Birmingham"); band64.setBandName("Dexys Midnight Runners"); band64.setGenre("Pop music, New wave, Soul music, Celtic music, Rock"); band64.setDescription("Dexys Midnight Runners are an English pop band with soul influences from Birmingham, who achieved major commercial success in the early to mid-1980s. They are best known in the UK for their songs Come On Eileen and Geno, both of which peaked at No. 1 on the UK Singles Chart, as well as six other top-20 singles.");

                Band band65 = new Band(); bands.Add(band65); band65.setBandCity("Sheffield"); band65.setBandName("Arctic Monkeys"); band65.setGenre("Indie rock, Garage rock, Post-punk revival"); band65.setDescription("Arctic Monkeys are an English rock band formed in Sheffield in 2002. The group consists of Alex Turner, Jamie Cook, Nick O'Malley, and Matt Helders. Former band member Andy Nicholson left the band in 2006 shortly after their debut album was released.");
                Band band66 = new Band(); bands.Add(band66); band66.setBandCity("Sheffield"); band66.setBandName("Pulp"); band66.setGenre("Britpop, Art rock, Glam rock, Indie pop"); band66.setDescription("Pulp were an English rock band formed in Sheffield in 1978. Their best-known line-up from their heyday consisted of Jarvis Cocker, Candida Doyle, Russell Senior, Mark Webber, Steve Mackey and Nick Banks.");
                Band band67 = new Band(); bands.Add(band67); band67.setBandCity("Sheffield"); band67.setBandName("The Human League"); band67.setGenre("Electropop, Pop"); band67.setDescription("The Human League are an English synth-pop band formed in Sheffield in 1977. Initially an experimental electronic outfit, the group signed to Virgin Records in 1979 and later attained widespread commercial success with their third album Dare in 1981.");
                Band band68 = new Band(); bands.Add(band68); band68.setBandCity("Sheffield"); band68.setBandName("Def Leppard"); band68.setGenre("Glam metal, Hard rock"); band68.setDescription("Def Leppard are an English rock band formed in 1977 in Sheffield. Since 1992, the band has consisted of Joe Elliott, Rick Savage, Rick Allen, Phil Collen, and Vivian Campbell, which has been the band's longest running line-up. They established themselves as part of the new wave of British heavy metal movement.");
                Band band69 = new Band(); bands.Add(band69); band69.setBandCity("Sheffield"); band69.setBandName("Cabaret Voltaire"); band69.setGenre("Industrial music, Post-punk, Electronic body music"); band69.setDescription("Cabaret Voltaire are an English music group formed in Sheffield in 1973 and initially composed of Stephen Mallinder, Richard H. Kirk, and Chris Watson. The group was named after the Cabaret Voltaire, the Zürich nightclub that served as a centre for the early Dada movement.");
                Band band70 = new Band(); bands.Add(band70); band70.setBandCity("Sheffield"); band70.setBandName("Reverend and the Makers"); band70.setGenre("Indie rock, Dance-rock, Electronica, Two-tone"); band70.setDescription("Reverend and the Makers are an English rock band from Sheffield, South Yorkshire. The band is fronted by Jon McClure, nicknamed The Reverend. Their debut album, The State of Things, helped them gain success in Britain and spawned the UK top 10 single Heavyweight Champion of the World.");
                Band band71 = new Band(); bands.Add(band71); band71.setBandCity("Sheffield"); band71.setBandName("Little Man Tate"); band71.setGenre("Indie rock"); band71.setDescription("Little Man Tate are a British four-piece indie rock band from Sheffield, England who formed in 2005. The band quickly began attracting interest from several record labels and in March 2006 signed to V2 Records.");
                Band band72 = new Band(); bands.Add(band72); band72.setBandCity("Sheffield"); band72.setBandName("Bring Me the Horizon"); band72.setGenre("Metalcore, Alternative metal, Alternative rock"); band72.setDescription("Bring Me the Horizon are a British rock band formed in Sheffield in 2004. The group consists of lead vocalist Oliver Sykes, guitarist Lee Malia, bassist Matt Kean, drummer Matt Nicholls and keyboardist Jordan Fish. They are signed to RCA Records globally and Columbia Records exclusively in the United States.");

                Band band73 = new Band(); bands.Add(band73); band73.setBandCity("Dublin"); band73.setBandName("U2"); band73.setGenre("Rock, Alternative rock, Post-punk"); band73.setDescription("U2 are an Irish rock band from Dublin, formed in 1976. The group consists of Bono, the Edge, Adam Clayton, and Larry Mullen Jr.");
                Band band74 = new Band(); bands.Add(band74); band74.setBandCity("Dublin"); band74.setBandName("My Bloody Valentine"); band74.setGenre("Shoegazing, Noise pop, Dream pop, Experimental rock, Post-punk"); band74.setDescription("My Bloody Valentine are an experimental rock band formed in Dublin in 1983. Since 1987, its lineup has consisted of founding members Kevin Shields and Colm Ó Cíosóig, with Bilinda Butcher and Debbie Googe.");
                Band band75 = new Band(); bands.Add(band75); band75.setBandCity("Dublin"); band75.setBandName("Westlife"); band75.setGenre("Pop music"); band75.setDescription("Westlife are an Irish boy band, which was formed 1998 in Sligo, Ireland. They disbanded in 2012 and reunited in 2018. They were originally signed by Simon Cowell in the UK, Clive Davis in the US and managed by Louis Walsh and Sonny Takhar.");
                Band band76 = new Band(); bands.Add(band76); band76.setBandCity("Dublin"); band76.setBandName("An Emotional Fish"); band76.setGenre("Alternative rock"); band76.setDescription("An Emotional Fish are an alternative rock band from Dublin, Ireland. An Emotional Fish were formed in 1988, and consisted of Gerard Whelan, Enda Wyatt, Martin Murphy and David Frew. Their musical influences include The Clash, The Doors, David Bowie, Iggy Pop, and T. Rex.");
                Band band77 = new Band(); bands.Add(band77); band77.setBandCity("Dublin"); band77.setBandName("The Script"); band77.setGenre("Folk rock, Soft rock, Indie rock, Pop rock"); band77.setDescription("The Script are an Irish rock band formed in 2007 in Dublin, Ireland. They first released music in 2008. It consists of lead vocalist and keyboardist Daniel O'Donoghue, lead guitarist Mark Sheehan, and drummer Glen Power.");
                Band band78 = new Band(); bands.Add(band78); band78.setBandCity("Dublin"); band78.setBandName("Thin Lizzy"); band78.setGenre("Hard rock, Blues rock, Heavy metal, Folk rock"); band78.setDescription("Thin Lizzy are a hard rock band formed in Dublin, Ireland, in 1969. Two of the founding members, drummer Brian Downey and bass guitarist and lead vocalist Phil Lynott, met while still in school. Lynott led the group throughout their recording career of twelve studio albums, writing most of the material.");
                Band band79 = new Band(); bands.Add(band79); band79.setBandCity("Dublin"); band79.setBandName("The Frames"); band79.setGenre("Rock, Indie rock, Folk music"); band79.setDescription("The Frames are an Irish rock band based in Dublin. Founded in 1990 by Glen Hansard, the band has been influential in the Dublin rock music scene. The group has released six studio albums.");
                Band band80 = new Band(); bands.Add(band80); band80.setBandCity("Dublin"); band80.setBandName("The Dubliners"); band80.setGenre("Irish traditional music"); band80.setDescription("The Dubliners were an Irish folk band founded in Dublin in 1962 as The Ronnie Drew Ballad Group, named after its founding member; they subsequently renamed themselves The Dubliners.");

                Initialise = true;
                button1.Text = "Reload";
                
            }

            listBox1.Items.Clear();
            listBox2.Items.Clear();
            foreach (string n in cities.getCityName())
            {
                listBox1.Items.Add(n);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string addBandName = Interaction.InputBox("Found a new band? Please enter the bands name! ").ToLower();
            string addCityName = Interaction.InputBox("What city is the band from? ").ToLower();
            string AddGenre = Interaction.InputBox("Genre?").ToLower();
            string AddDes = Interaction.InputBox("Description for the band? Age created? Members of the band?");
            Band addBand = new Band(); bands.Add(addBand); addBand.setBandName(addBandName); addBand.setBandCity(addCityName); addBand.setGenre(AddGenre); addBand.setDescription(AddDes);

            bool foundCity = false;

            foreach (string n in cities.getCityName()) 
            {
                if(addCityName == n) 
                {
                    foundCity = true;
                    return;
                }
            }

            if(!foundCity) // if city does not previously exist
            {
                City city11 = new City(); cities.Add(city11); city11.setCityName(addCityName); //create city
            }

            listBox1.Items.Clear();
            foreach (string n in cities.getCityName())
            {
                listBox1.Items.Add(n);
            }

            listBox2.Items.Clear();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
           
            //Alternative Method

            //List<string> filteredBands = bands.getBands()
            //    .Where(band => band.getBandCity() == listBox1.SelectedItem) // Filter all the bands (basically a mini foreach loop) //
            //    .Select(band => band.getBandName()) // Loop through each result from the previous line, and only return the band name //
            //    .ToList(); // Turn it into a list //
            //filteredBands.ForEach(band => listBox2.Items.Add(band)); // This is the same as doing a foreach() loop like below //

            if(listBox1.SelectedItem == null) 
            {
                return;
            }
            foreach (Band band in bands.getBands())
            {
                if (band.getBandCity() == listBox1.SelectedItem.ToString())
                {
                    listBox2.Items.Add(band.getBandName());
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string choice = Interaction.InputBox("Would you like to search by Name or Genre?").ToLower();


            if (choice == "name") 
            {
                string name = Interaction.InputBox("Search for the band you are looking for").ToLower();

                Band bandsSearch = bands.Search(name);
                if (bandsSearch != null)
                {
                    listBox2.Items.Clear();
                    listBox2.Items.Add(bandsSearch.getBandName());

                    listBox1.Items.Clear();

                    foreach (City city in cities.getCities())
                    {
                        if (city.getCityName() == bandsSearch.getBandCity())
                        {
                            listBox1.Items.Add(city.getCityName());
                        }
                    }
                    MessageBox.Show("We found " + name);

                }
                else
                {
                    MessageBox.Show("This band was not found, but you can add it to the system!");
                }
            }

            if (choice == "genre") 
            {
                string genre = Interaction.InputBox("Search for the Genre you are looking for").ToLower();
                bool genreFound = false;

                listBox2.Items.Clear();
                foreach (Band band in bands.getBands())
                {
                    if (band.getGenre().Contains(genre))
                    {
                        listBox2.Items.Add(band.getBandName());
                        genreFound = true;
                    }
                }
                if(genreFound) 
                {
                    MessageBox.Show("We found some bands from the Genre: " + genre);
                }
                if (!genreFound) 
                {
                    MessageBox.Show("Sorry we could not find bands from the Genre: " + genre);
                }
            }
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listBox2.SelectedItem == null) 
            {
                return;
            }
            foreach (Band band in bands.getBands())
            {
                if (band.getBandName() == listBox2.SelectedItem.ToString())
                {
                    MessageBox.Show(band.getDescription() + "\n" +"\n" + "Genre : " + band.getGenre(), "About Band");
                }
            }
        }
    }
}
