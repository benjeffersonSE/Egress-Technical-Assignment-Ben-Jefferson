﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BandFinder
{
    class City
    {
        //initialise data 
        private string cityName;

        //retrive data
        public string getCityName()
        {
            return cityName.ToLower();
        }

        //mutate data

        internal void setCityName(string cityName)
        {
            (this.cityName = cityName).ToLower();
        }
    }
}
