﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace BandFinder
{
    class Band
    {

        //initialising data
        private string bandName = "";
        private string bandCity = "";
        private string Genre = "";
        private string Description = "";

        //retreving data
        public string getBandName()
        {
            return bandName.ToLower();
        }

        public string getBandCity()
        {
            return bandCity.ToLower();
        }

        public string getDescription()
        {
            return Description;
        }

        public string getGenre() 
        {
            return Genre.ToLower();
        }

        //mutate data

        public void setBandName(string bandName) 
        {
            (this.bandName = bandName).ToLower();
        }

        public void setBandCity(string bandCity) 
        {
            (this.bandCity = bandCity).ToLower(); ;
        }

        public void setGenre(string Genre) 
        {
            (this.Genre = Genre).ToLower();
        }

        public void setDescription(string Description)
        {
            this.Description = Description;
        }
    }
}
