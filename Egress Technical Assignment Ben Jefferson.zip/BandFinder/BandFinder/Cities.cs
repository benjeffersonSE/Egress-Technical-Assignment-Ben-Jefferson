﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace BandFinder
{
    class Cities
    {
        public void Add(City city)
        {
            cities.Add(city);
        }

        List<City> cities = new List<City>();

        public List<City> getCities()
        {
            return cities;
        }

        public List<string> getCityName()
        {
            List<string> names = new List<string>();
            foreach (City city in cities)
            {
                names.Add(city.getCityName());
            }
            return names;
        }

        public bool Search(string name)
        {
            foreach (City city in cities)
            {
                if (name == city.getCityName())
                {
                    return true;
                }
            }
            return false;
        }
    }
}
