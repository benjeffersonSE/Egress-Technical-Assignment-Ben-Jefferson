﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Class1
{
	public Class1()
	{
        List<Band> bands = new List<Band>();

        public List<string> getBandName()
        {
            List<string> bands = new List<string>();
            foreach (Band bans in bands)
            {
                bands.Add(Band.get)
            }
        }

        public void Add(Band band)
        {
            bands.Add(band);
        }
    }
}
